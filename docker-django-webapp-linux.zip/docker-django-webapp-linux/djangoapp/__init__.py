"""
Package for djangoapp.
"""
